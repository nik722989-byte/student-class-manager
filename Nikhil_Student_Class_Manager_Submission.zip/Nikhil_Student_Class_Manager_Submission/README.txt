STUDENT CLASS MANAGER - MINI PROJECT
=====================================

WHAT IS INCLUDED?
- index.html: website structure
- style.css: responsive design and colours
- script.js: browser demo functionality (students, attendance, activities)
- StudentClassManager.cpp: separate C++ console application

IMPORTANT:
HTML and CSS make the website interface. The included C++ file is a separate
console version of the same project. A normal browser cannot directly execute
a C++ program. To connect a real website to a C++ backend, you would need a
server/API (for example, C++ with a web framework) and a database. This
beginner version keeps the website functional using JavaScript and localStorage.

HOW TO OPEN THE WEBSITE ON YOUR COMPUTER
1. Extract the ZIP file into a folder.
2. Open the Student_Class_Manager folder.
3. Double-click index.html. It should open in Chrome, Edge, or Firefox.
4. Add students, mark attendance, and add activities.
5. Data is stored only in that browser on that computer. Clearing browser data
   may remove it. This is a demo, not a secure multi-user school database.

HOW TO PUT IT ONLINE USING GOOGLE CHROME + GITHUB PAGES
1. Sign in to https://github.com/ or create an account.
2. Click the + menu, then New repository.
3. Name it student-class-manager. Choose Public, then Create repository.
4. Upload index.html, style.css and script.js to the repository's root.
   (The C++ file is not needed to host the website.)
5. Open the repository's Settings > Pages.
6. Under Build and deployment, select Deploy from a branch.
7. Select the main branch and /(root), then Save.
8. Wait a few minutes. GitHub Pages will show your website URL in Settings > Pages.
9. Open that URL in Chrome to view your site online.

Google Sites alternative:
1. Go to https://sites.google.com/ and create a site.
2. Google Sites does not directly host a folder of HTML/CSS/JS files as a normal
   website. First host this project on GitHub Pages, then in Google Sites choose
   Insert > Embed > By URL and paste your published GitHub Pages URL.
3. Publish your Google Site. Embedding availability can depend on browser and
   site settings.

HOW TO RUN THE C++ VERSION
1. Install a C++ compiler such as g++ (MinGW-w64 on Windows, or g++ on Linux).
2. Open a terminal/command prompt in the folder containing StudentClassManager.cpp.
3. Compile:
      g++ StudentClassManager.cpp -o student_manager
4. Run on Windows:
      student_manager.exe
   On Linux/macOS:
      ./student_manager

MINI-PROJECT REPORT OUTLINE
Title: Student Class Manager
Objective: To manage student details, daily attendance, class/section and
           classroom activities using a simple digital interface.
Tools: HTML, CSS, JavaScript (website demo), C++ (console version).
Modules: Student Registration, Attendance, Class Information, Activities.
Future scope: Database integration, login for teachers/admin, attendance reports,
              export to CSV/PDF, and a C++ web API.
