const $ = (id) => document.getElementById(id);
const read = (key, fallback) => {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
  catch { return fallback; }
};
let students = read("classtrack_students", []);
let activities = read("classtrack_activities", []);
let attendance = read("classtrack_attendance", {});
const today = new Date().toISOString().slice(0, 10);
$("attendanceDate").value = today;
$("activityDate").value = today;

function save() {
  localStorage.setItem("classtrack_students", JSON.stringify(students));
  localStorage.setItem("classtrack_activities", JSON.stringify(activities));
  localStorage.setItem("classtrack_attendance", JSON.stringify(attendance));
}
function render() {
  const date = $("attendanceDate").value || today;
  const day = attendance[date] || {};
  $("totalStudents").textContent = students.length;
  $("presentCount").textContent = students.filter(s => day[s.id] === "Present").length;
  $("absentCount").textContent = students.filter(s => day[s.id] === "Absent").length;
  $("activityCount").textContent = activities.length;
  const body = $("attendanceTable");
  body.innerHTML = "";
  if (!students.length) {
    body.innerHTML = '<tr><td colspan="4" class="empty">No students yet. Add a student above to begin.</td></tr>';
  } else {
    students.forEach(s => {
      const status = day[s.id] || "";
      const tr = document.createElement("tr");
      tr.innerHTML = `<td class="roll"></td><td></td><td></td><td><div class="attendance-actions">
        <button data-status="Present" class="${status === "Present" ? "selected present" : ""}">Present</button>
        <button data-status="Absent" class="${status === "Absent" ? "selected absent" : ""}">Absent</button>
      </div></td>`;
      tr.children[0].textContent = s.roll;
      tr.children[1].textContent = s.name;
      tr.children[2].textContent = s.className;
      tr.querySelectorAll("button").forEach(btn => btn.addEventListener("click", () => {
        attendance[date] = attendance[date] || {};
        attendance[date][s.id] = btn.dataset.status;
        save(); render();
      }));
      body.appendChild(tr);
    });
  }
  const list = $("activityList");
  list.innerHTML = "";
  if (!activities.length) list.innerHTML = '<p class="empty">No activities added yet.</p>';
  activities.forEach(a => {
    const card = document.createElement("article");
    card.className = "activity-item";
    const info = document.createElement("div");
    const name = document.createElement("strong"); name.textContent = a.name;
    const meta = document.createElement("span"); meta.textContent = `${a.className} · ${a.date}`;
    info.append(name, meta);
    const del = document.createElement("button"); del.textContent = "Remove";
    del.addEventListener("click", () => { activities = activities.filter(x => x.id !== a.id); save(); render(); });
    card.append(info, del); list.appendChild(card);
  });
}
$("studentForm").addEventListener("submit", e => {
  e.preventDefault();
  const name = $("studentName").value.trim(), roll = $("rollNumber").value.trim();
  if (students.some(s => s.roll.toLowerCase() === roll.toLowerCase())) {
    alert("That roll number already exists. Please use a unique roll number."); return;
  }
  students.push({ id: String(Date.now()) + Math.random().toString(16).slice(2), name, roll, className: $("className").value });
  save(); e.target.reset(); render();
});
$("activityForm").addEventListener("submit", e => {
  e.preventDefault();
  activities.push({ id: String(Date.now()) + Math.random().toString(16).slice(2), name: $("activityName").value.trim(), className: $("activityClass").value, date: $("activityDate").value });
  save(); e.target.reset(); $("activityDate").value = today; render();
});
$("attendanceDate").addEventListener("change", render);
render();
