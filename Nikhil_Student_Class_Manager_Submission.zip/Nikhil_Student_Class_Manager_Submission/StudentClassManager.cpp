// Student Class Manager - simple C++ console mini project
// Compile: g++ StudentClassManager.cpp -o student_manager
// Run:     ./student_manager  (Windows: student_manager.exe)
#include <iostream>
#include <vector>
#include <string>
#include <limits>
using namespace std;

struct Student {
    string name, roll, className;
    int present = 0, absent = 0;
};
struct Activity {
    string title, className, date;
};
vector<Student> students;
vector<Activity> activities;

int findStudent(const string& roll) {
    for (int i = 0; i < (int)students.size(); ++i)
        if (students[i].roll == roll) return i;
    return -1;
}
void addStudent() {
    Student s;
    cout << "Student name: "; getline(cin, s.name);
    cout << "Roll number: "; getline(cin, s.roll);
    if (findStudent(s.roll) != -1) {
        cout << "That roll number already exists.\\n"; return;
    }
    cout << "Class / section: "; getline(cin, s.className);
    students.push_back(s);
    cout << "Student added successfully.\\n";
}
void listStudents() {
    if (students.empty()) { cout << "No students added yet.\\n"; return; }
    cout << "\\n--- STUDENT LIST ---\\n";
    for (const auto& s : students)
        cout << "Roll: " << s.roll << " | " << s.name
             << " | Class: " << s.className
             << " | Present: " << s.present << " | Absent: " << s.absent << '\\n';
}
void markAttendance() {
    string roll, status;
    cout << "Enter student roll number: "; getline(cin, roll);
    int i = findStudent(roll);
    if (i == -1) { cout << "Student not found. Add the student first.\\n"; return; }
    cout << "Enter P for Present or A for Absent: "; getline(cin, status);
    if (status == "P" || status == "p") {
        ++students[i].present; cout << "Marked present.\\n";
    } else if (status == "A" || status == "a") {
        ++students[i].absent; cout << "Marked absent.\\n";
    } else cout << "Invalid choice. Attendance not changed.\\n";
}
void addActivity() {
    Activity a;
    cout << "Activity name: "; getline(cin, a.title);
    cout << "Class / section: "; getline(cin, a.className);
    cout << "Date (DD-MM-YYYY): "; getline(cin, a.date);
    activities.push_back(a);
    cout << "Activity added successfully.\\n";
}
void listActivities() {
    if (activities.empty()) { cout << "No activities added yet.\\n"; return; }
    cout << "\\n--- CLASS ACTIVITIES ---\\n";
    for (const auto& a : activities)
        cout << a.title << " | " << a.className << " | " << a.date << '\\n';
}
int main() {
    int choice;
    do {
        cout << "\\n========== STUDENT CLASS MANAGER ==========\\n"
             << "1. Add student\\n"
             << "2. View students and attendance totals\\n"
             << "3. Mark attendance\\n"
             << "4. Add class activity\\n"
             << "5. View class activities\\n"
             << "0. Exit\\n"
             << "Enter choice: ";
        if (!(cin >> choice)) {
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\\n');
            cout << "Please enter a number.\\n"; continue;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\\n');
        switch (choice) {
            case 1: addStudent(); break;
            case 2: listStudents(); break;
            case 3: markAttendance(); break;
            case 4: addActivity(); break;
            case 5: listActivities(); break;
            case 0: cout << "Goodbye!\\n"; break;
            default: cout << "Invalid choice. Try again.\\n";
        }
    } while (choice != 0);
    return 0;
}
